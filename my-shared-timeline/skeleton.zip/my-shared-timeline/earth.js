{
  "name": "Earth",
  "populations": [
    "dinosaurs": 0,
    "asteroids": 0,
    "mammoths": 0,
    "humans": 100+,
  ]
}
